import sqlite3
import os

# Delete existing database if exists
if os.path.exists('collabdb.db'):
    os.remove('collabdb.db')
    print("Old database removed")

# Create new database
conn = sqlite3.connect('collabdb.db')
cursor = conn.cursor()

print("Creating database...")

# Read and execute the SQL file
with open('database.sql', 'r', encoding='utf-8') as f:
    sql_script = f.read()

# Split by semicolon and execute each statement
statements = sql_script.split(';')
for statement in statements:
    statement = statement.strip()
    if statement and not statement.startswith('--'):
        try:
            cursor.execute(statement)
            if 'CREATE TABLE' in statement.upper():
                table_name = statement.split('CREATE TABLE')[1].split('(')[0].strip()
                print(f"✓ Created table: {table_name}")
        except Exception as e:
            print(f"Error executing: {statement[:50]}...")
            print(f"Error: {e}")

conn.commit()
conn.close()

print("\n✅ Database created successfully: collabdb.db")
print("✅ Tables: Users, Tasks, Comments, ActivityLog, ChatMessages")
print("✅ Sample data inserted: 7 users, 7 tasks")
print("\nNow run: python app.py")