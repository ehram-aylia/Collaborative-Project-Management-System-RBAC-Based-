// Accessibility Features for Collaboration Board
class AccessibilityManager {
    constructor() {
        this.settings = {
            highContrast: false,
            largeText: false,
            reducedMotion: false,
            dyslexiaFont: false,
            screenReader: false
        };
        
        this.init();
    }

    init() {
        // Load saved settings
        this.loadSettings();
        
        // Apply initial settings
        this.applySettings();
        
        // Initialize accessibility controls
        this.initControls();
        
        // Setup keyboard navigation
        this.setupKeyboardNavigation();
        
        // Setup screen reader announcements
        this.setupScreenReader();
    }

    loadSettings() {
        // Load from localStorage
        this.settings.highContrast = localStorage.getItem('highContrast') === 'true';
        this.settings.largeText = localStorage.getItem('largeText') === 'true';
        this.settings.reducedMotion = localStorage.getItem('reducedMotion') === 'true';
        this.settings.dyslexiaFont = localStorage.getItem('dyslexiaFont') === 'true';
        this.settings.screenReader = localStorage.getItem('screenReader') === 'true';
    }

    saveSettings() {
        localStorage.setItem('highContrast', this.settings.highContrast);
        localStorage.setItem('largeText', this.settings.largeText);
        localStorage.setItem('reducedMotion', this.settings.reducedMotion);
        localStorage.setItem('dyslexiaFont', this.settings.dyslexiaFont);
        localStorage.setItem('screenReader', this.settings.screenReader);
    }

    applySettings() {
        const body = document.body;
        
        // High contrast
        if (this.settings.highContrast) {
            body.classList.add('high-contrast');
            document.getElementById('contrast-toggle')?.classList.add('active');
        } else {
            body.classList.remove('high-contrast');
            document.getElementById('contrast-toggle')?.classList.remove('active');
        }
        
        // Large text
        if (this.settings.largeText) {
            body.classList.add('large-text');
            document.getElementById('text-toggle')?.classList.add('active');
        } else {
            body.classList.remove('large-text');
            document.getElementById('text-toggle')?.classList.remove('active');
        }
        
        // Reduced motion
        if (this.settings.reducedMotion) {
            body.classList.add('reduced-motion');
            document.getElementById('motion-toggle')?.classList.add('active');
            
            // Disable CSS animations and transitions
            const style = document.createElement('style');
            style.id = 'reduced-motion-style';
            style.textContent = `
                *, *::before, *::after {
                    animation-duration: 0.001ms !important;
                    animation-iteration-count: 1 !important;
                    transition-duration: 0.001ms !important;
                }
            `;
            document.head.appendChild(style);
        } else {
            body.classList.remove('reduced-motion');
            document.getElementById('motion-toggle')?.classList.remove('active');
            
            const style = document.getElementById('reduced-motion-style');
            if (style) style.remove();
        }
        
        // Dyslexia-friendly font
        if (this.settings.dyslexiaFont) {
            body.classList.add('dyslexia-font');
            document.getElementById('dyslexia-toggle')?.classList.add('active');
        } else {
            body.classList.remove('dyslexia-font');
            document.getElementById('dyslexia-toggle')?.classList.remove('active');
        }
        
        // Screen reader announcements
        if (this.settings.screenReader) {
            this.enableScreenReader();
            document.getElementById('reader-toggle')?.classList.add('active');
        } else {
            this.disableScreenReader();
            document.getElementById('reader-toggle')?.classList.remove('active');
        }
    }

    initControls() {
        // Create accessibility panel if it doesn't exist
        if (!document.getElementById('accessibility-panel')) {
            const panelHTML = `
                <div id="accessibility-panel" class="accessibility-panel">
                    <div class="panel-header">
                        <h4><i class="fas fa-universal-access"></i> Accessibility</h4>
                        <button id="close-panel"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="panel-content">
                        <div class="accessibility-option">
                            <label>
                                <input type="checkbox" id="contrast-toggle" ${this.settings.highContrast ? 'checked' : ''}>
                                <span>High Contrast</span>
                            </label>
                            <p class="option-desc">Increase color contrast for better visibility</p>
                        </div>
                        
                        <div class="accessibility-option">
                            <label>
                                <input type="checkbox" id="text-toggle" ${this.settings.largeText ? 'checked' : ''}>
                                <span>Large Text</span>
                            </label>
                            <p class="option-desc">Increase text size by 20%</p>
                        </div>
                        
                        <div class="accessibility-option">
                            <label>
                                <input type="checkbox" id="motion-toggle" ${this.settings.reducedMotion ? 'checked' : ''}>
                                <span>Reduce Motion</span>
                            </label>
                            <p class="option-desc">Reduce animations and transitions</p>
                        </div>
                        
                        <div class="accessibility-option">
                            <label>
                                <input type="checkbox" id="dyslexia-toggle" ${this.settings.dyslexiaFont ? 'checked' : ''}>
                                <span>Dyslexia-Friendly Font</span>
                            </label>
                            <p class="option-desc">Use OpenDyslexic font</p>
                        </div>
                        
                        <div class="accessibility-option">
                            <label>
                                <input type="checkbox" id="reader-toggle" ${this.settings.screenReader ? 'checked' : ''}>
                                <span>Screen Reader Mode</span>
                            </label>
                            <p class="option-desc">Enhanced screen reader support</p>
                        </div>
                        
                        <div class="keyboard-help">
                            <h5><i class="fas fa-keyboard"></i> Keyboard Shortcuts</h5>
                            <ul>
                                <li><kbd>Tab</kbd> Navigate elements</li>
                                <li><kbd>Shift + Tab</kbd> Navigate backward</li>
                                <li><kbd>Enter/Space</kbd> Activate buttons</li>
                                <li><kbd>ESC</kbd> Close dialogs</li>
                                <li><kbd>Ctrl + /</kbd> Show shortcuts</li>
                                <li><kbd>Alt + A</kbd> Accessibility panel</li>
                            </ul>
                        </div>
                    </div>
                    <button id="accessibility-toggle" class="accessibility-toggle">
                        <i class="fas fa-universal-access"></i>
                    </button>
                </div>
            `;
            
            document.body.insertAdjacentHTML('beforeend', panelHTML);
            
            // Add event listeners
            document.getElementById('accessibility-toggle').addEventListener('click', () => this.togglePanel());
            document.getElementById('close-panel').addEventListener('click', () => this.togglePanel());
            
            // Add change listeners for checkboxes
            document.getElementById('contrast-toggle').addEventListener('change', (e) => {
                this.settings.highContrast = e.target.checked;
                this.applySettings();
                this.saveSettings();
                this.announce('High contrast mode ' + (e.target.checked ? 'enabled' : 'disabled'));
            });
            
            document.getElementById('text-toggle').addEventListener('change', (e) => {
                this.settings.largeText = e.target.checked;
                this.applySettings();
                this.saveSettings();
                this.announce('Large text mode ' + (e.target.checked ? 'enabled' : 'disabled'));
            });
            
            document.getElementById('motion-toggle').addEventListener('change', (e) => {
                this.settings.reducedMotion = e.target.checked;
                this.applySettings();
                this.saveSettings();
                this.announce('Reduced motion ' + (e.target.checked ? 'enabled' : 'disabled'));
            });
            
            document.getElementById('dyslexia-toggle').addEventListener('change', (e) => {
                this.settings.dyslexiaFont = e.target.checked;
                this.applySettings();
                this.saveSettings();
                this.announce('Dyslexia-friendly font ' + (e.target.checked ? 'enabled' : 'disabled'));
            });
            
            document.getElementById('reader-toggle').addEventListener('change', (e) => {
                this.settings.screenReader = e.target.checked;
                this.applySettings();
                this.saveSettings();
                this.announce('Screen reader mode ' + (e.target.checked ? 'enabled' : 'disabled'));
            });
        }
    }

    togglePanel() {
        const panel = document.getElementById('accessibility-panel');
        panel.classList.toggle('open');
    }

    setupKeyboardNavigation() {
        // Make all interactive elements focusable
        document.addEventListener('DOMContentLoaded', () => {
            const interactiveElements = document.querySelectorAll('button, input, select, textarea, a[href]');
            interactiveElements.forEach(el => {
                if (!el.hasAttribute('tabindex')) {
                    el.setAttribute('tabindex', '0');
                }
            });
        });
        
        // Add keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Alt + A: Toggle accessibility panel
            if (e.altKey && e.key === 'a') {
                e.preventDefault();
                this.togglePanel();
            }
            
            // Ctrl + /: Show keyboard help
            if (e.ctrlKey && e.key === '/') {
                e.preventDefault();
                this.showKeyboardHelp();
            }
            
            // Escape: Close all modals
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
    }

    setupScreenReader() {
        // Create live region for announcements
        if (!document.getElementById('sr-announce')) {
            const announceDiv = document.createElement('div');
            announceDiv.id = 'sr-announce';
            announceDiv.setAttribute('aria-live', 'polite');
            announceDiv.setAttribute('aria-atomic', 'true');
            announceDiv.className = 'sr-only';
            document.body.appendChild(announceDiv);
        }
    }

    enableScreenReader() {
        // Add screen reader specific attributes
        document.querySelectorAll('img').forEach(img => {
            if (!img.hasAttribute('alt')) {
                img.setAttribute('alt', 'Decorative image');
            }
        });
        
        document.querySelectorAll('button').forEach(btn => {
            if (!btn.hasAttribute('aria-label')) {
                const text = btn.textContent.trim() || btn.title || 'Button';
                btn.setAttribute('aria-label', text);
            }
        });
        
        // Add skip to main content link
        if (!document.getElementById('skip-to-main')) {
            const skipLink = document.createElement('a');
            skipLink.href = '#main-content';
            skipLink.id = 'skip-to-main';
            skipLink.className = 'skip-link';
            skipLink.textContent = 'Skip to main content';
            document.body.insertBefore(skipLink, document.body.firstChild);
        }
    }

    disableScreenReader() {
        // Remove skip link
        const skipLink = document.getElementById('skip-to-main');
        if (skipLink) skipLink.remove();
    }

    announce(message) {
        if (this.settings.screenReader) {
            const announceDiv = document.getElementById('sr-announce');
            if (announceDiv) {
                announceDiv.textContent = message;
                
                // Clear after announcement
                setTimeout(() => {
                    announceDiv.textContent = '';
                }, 1000);
            }
        }
        
        // Also show visual notification
        this.showNotification(message, 'info');
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `accessibility-notification notification-${type}`;
        notification.setAttribute('role', 'alert');
        notification.innerHTML = `
            <span>${message}</span>
            <button onclick="this.parentElement.remove()" aria-label="Close notification">×</button>
        `;
        
        // Add to page
        const container = document.getElementById('notifications') || document.body;
        container.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }

    showKeyboardHelp() {
        const helpHTML = `
            <div class="keyboard-help-modal" role="dialog" aria-labelledby="help-title">
                <div class="modal-content">
                    <h3 id="help-title"><i class="fas fa-keyboard"></i> Keyboard Shortcuts</h3>
                    <div class="shortcuts-grid">
                        <div class="shortcut-item">
                            <kbd>Alt</kbd> + <kbd>A</kbd>
                            <span>Accessibility panel</span>
                        </div>
                        <div class="shortcut-item">
                            <kbd>Ctrl</kbd> + <kbd>N</kbd>
                            <span>New task</span>
                        </div>
                        <div class="shortcut-item">
                            <kbd>Ctrl</kbd> + <kbd>F</kbd>
                            <span>Search tasks</span>
                        </div>
                        <div class="shortcut-item">
                            <kbd>Ctrl</kbd> + <kbd>S</kbd>
                            <span>Save changes</span>
                        </div>
                        <div class="shortcut-item">
                            <kbd>ESC</kbd>
                            <span>Close dialog</span>
                        </div>
                        <div class="shortcut-item">
                            <kbd>Tab</kbd>
                            <span>Next element</span>
                        </div>
                        <div class="shortcut-item">
                            <kbd>Shift</kbd> + <kbd>Tab</kbd>
                            <span>Previous element</span>
                        </div>
                        <div class="shortcut-item">
                            <kbd>F1</kbd>
                            <span>Help</span>
                        </div>
                    </div>
                    <button class="close-help" onclick="this.parentElement.parentElement.remove()">Close</button>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', helpHTML);
    }

    closeAllModals() {
        // Close all modal-like elements
        document.querySelectorAll('.modal, .keyboard-help-modal, .accessibility-panel.open').forEach(el => {
            if (!el.classList.contains('accessibility-panel')) {
                el.remove();
            }
        });
        
        // Close accessibility panel if open
        const panel = document.getElementById('accessibility-panel');
        if (panel && panel.classList.contains('open')) {
            panel.classList.remove('open');
        }
    }
}

// Initialize accessibility manager
document.addEventListener('DOMContentLoaded', function() {
    window.accessibilityManager = new AccessibilityManager();
});