// Notification System for Collaboration Board
class NotificationSystem {
    constructor(socket) {
        this.socket = socket;
        this.notifications = [];
        this.permission = 'default'; // default, granted, denied
        this.init();
    }

    init() {
        // Request notification permission
        this.requestPermission();
        
        // Listen for socket notifications
        this.setupSocketListeners();
        
        // Initialize UI
        this.initUI();
        
        // Setup periodic checks
        this.setupPeriodicChecks();
    }

    requestPermission() {
        if ('Notification' in window) {
            if (Notification.permission === 'granted') {
                this.permission = 'granted';
            } else if (Notification.permission !== 'denied') {
                Notification.requestPermission().then(permission => {
                    this.permission = permission;
                    if (permission === 'granted') {
                        this.showBrowserNotification('Notifications enabled', 'You will now receive notifications for important updates.');
                    }
                });
            }
        }
    }

    setupSocketListeners() {
        // Task-related notifications
        this.socket.on('task_assigned', (data) => {
            this.showNotification(`Task assigned: ${data.title}`, 'You have been assigned a new task.', 'assignment', data.task_id);
        });

        this.socket.on('task_updated', (data) => {
            this.showNotification(`Task updated: ${data.title}`, `Status changed to ${data.status}`, 'update', data.task_id);
        });

        this.socket.on('task_due_soon', (data) => {
            this.showNotification(`Due soon: ${data.title}`, `Due in ${data.days_left} days`, 'urgent', data.task_id);
        });

        this.socket.on('comment_added', (data) => {
            this.showNotification(`New comment on ${data.title}`, `${data.user}: ${data.comment.substring(0, 50)}...`, 'comment', data.task_id);
        });

        this.socket.on('user_mentioned', (data) => {
            this.showNotification(`You were mentioned`, `${data.user} mentioned you in a comment`, 'mention', data.task_id);
        });

        this.socket.on('system_alert', (data) => {
            this.showNotification(data.title, data.message, 'system');
        });
    }

    initUI() {
        // Create notifications container if it doesn't exist
        if (!document.getElementById('notifications-panel')) {
            const panelHTML = `
                <div id="notifications-panel" class="notifications-panel">
                    <div class="notifications-header">
                        <h4><i class="fas fa-bell"></i> Notifications</h4>
                        <div class="notifications-controls">
                            <button id="mark-all-read" title="Mark all as read">✓</button>
                            <button id="clear-notifications" title="Clear all">×</button>
                            <button id="close-notifications" title="Close">✕</button>
                        </div>
                    </div>
                    <div class="notifications-list" id="notifications-list">
                        <div class="empty-notifications">
                            <i class="fas fa-bell-slash"></i>
                            <p>No notifications yet</p>
                        </div>
                    </div>
                    <div class="notifications-footer">
                        <label>
                            <input type="checkbox" id="desktop-notifications" ${this.permission === 'granted' ? 'checked' : ''}>
                            Desktop notifications
                        </label>
                    </div>
                    <button id="notifications-toggle" class="notifications-toggle">
                        <i class="fas fa-bell"></i>
                        <span class="notifications-badge">0</span>
                    </button>
                </div>
            `;
            
            document.body.insertAdjacentHTML('beforeend', panelHTML);
            
            // Add event listeners
            document.getElementById('notifications-toggle').addEventListener('click', () => this.togglePanel());
            document.getElementById('close-notifications').addEventListener('click', () => this.togglePanel());
            document.getElementById('mark-all-read').addEventListener('click', () => this.markAllAsRead());
            document.getElementById('clear-notifications').addEventListener('click', () => this.clearAll());
            document.getElementById('desktop-notifications').addEventListener('change', (e) => {
                this.toggleDesktopNotifications(e.target.checked);
            });
        }
    }

    showNotification(title, message, type = 'info', taskId = null) {
        const notification = {
            id: Date.now(),
            title,
            message,
            type,
            taskId,
            timestamp: new Date(),
            read: false
        };
        
        // Add to array
        this.notifications.unshift(notification);
        
        // Update UI
        this.updateNotificationUI();
        
        // Show browser notification
        if (this.permission === 'granted' && document.hidden) {
            this.showBrowserNotification(title, message);
        }
        
        // Play sound for important notifications
        if (type === 'urgent' || type === 'mention') {
            this.playNotificationSound();
        }
        
        // Save to localStorage
        this.saveToStorage();
        
        // Return notification for chaining
        return notification;
    }

    showBrowserNotification(title, message) {
        if ('Notification' in window && Notification.permission === 'granted') {
            const icon = '/static/images/notification-icon.png'; // You need to add this icon
            
            const notification = new Notification(title, {
                body: message,
                icon: icon || '/favicon.ico',
                tag: 'collab-notification'
            });
            
            notification.onclick = () => {
                window.focus();
                this.togglePanel();
                notification.close();
            };
            
            setTimeout(() => notification.close(), 5000);
        }
    }

    updateNotificationUI() {
        const list = document.getElementById('notifications-list');
        const badge = document.querySelector('.notifications-badge');
        
        if (!list) return;
        
        // Calculate unread count
        const unreadCount = this.notifications.filter(n => !n.read).length;
        badge.textContent = unreadCount > 9 ? '9+' : unreadCount;
        
        // Clear list if empty
        if (this.notifications.length === 0) {
            list.innerHTML = `
                <div class="empty-notifications">
                    <i class="fas fa-bell-slash"></i>
                    <p>No notifications yet</p>
                </div>
            `;
            return;
        }
        
        // Generate notifications list
        let html = '';
        this.notifications.forEach(notification => {
            const timeAgo = this.getTimeAgo(notification.timestamp);
            const icon = this.getNotificationIcon(notification.type);
            
            html += `
                <div class="notification-item ${notification.read ? 'read' : 'unread'}" data-id="${notification.id}">
                    <div class="notification-icon ${notification.type}">${icon}</div>
                    <div class="notification-content">
                        <div class="notification-title">${notification.title}</div>
                        <div class="notification-message">${notification.message}</div>
                        <div class="notification-time">${timeAgo}</div>
                    </div>
                    <div class="notification-actions">
                        ${notification.taskId ? 
                            `<button class="goto-task" data-task="${notification.taskId}" title="Go to task">↗</button>` : 
                            ''
                        }
                        <button class="mark-read" title="Mark as read">✓</button>
                    </div>
                </div>
            `;
        });
        
        list.innerHTML = html;
        
        // Add event listeners to new items
        list.querySelectorAll('.notification-item').forEach(item => {
            const id = parseInt(item.dataset.id);
            
            // Mark as read on click
            item.addEventListener('click', (e) => {
                if (!e.target.closest('.notification-actions')) {
                    this.markAsRead(id);
                    item.classList.add('read');
                }
            });
            
            // Go to task button
            const gotoBtn = item.querySelector('.goto-task');
            if (gotoBtn) {
                gotoBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const taskId = gotoBtn.dataset.task;
                    this.goToTask(taskId);
                });
            }
            
            // Mark read button
            const markBtn = item.querySelector('.mark-read');
            if (markBtn) {
                markBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.markAsRead(id);
                    item.classList.add('read');
                });
            }
        });
    }

    getNotificationIcon(type) {
        const icons = {
            'assignment': '📋',
            'update': '🔄',
            'urgent': '⚠️',
            'comment': '💬',
            'mention': '@',
            'system': '🔔',
            'info': 'ℹ️'
        };
        return icons[type] || '🔔';
    }

    getTimeAgo(timestamp) {
        const now = new Date();
        const diff = now - new Date(timestamp);
        
        const seconds = Math.floor(diff / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        
        if (days > 0) return `${days}d ago`;
        if (hours > 0) return `${hours}h ago`;
        if (minutes > 0) return `${minutes}m ago`;
        return 'Just now';
    }

    togglePanel() {
        const panel = document.getElementById('notifications-panel');
        panel.classList.toggle('open');
        
        // Mark all as read when opening panel
        if (panel.classList.contains('open')) {
            this.markAllAsRead();
        }
    }

    markAsRead(id) {
        const notification = this.notifications.find(n => n.id === id);
        if (notification) {
            notification.read = true;
            this.updateNotificationUI();
            this.saveToStorage();
        }
    }

    markAllAsRead() {
        this.notifications.forEach(n => n.read = true);
        this.updateNotificationUI();
        this.saveToStorage();
    }

    clearAll() {
        if (confirm('Clear all notifications?')) {
            this.notifications = [];
            this.updateNotificationUI();
            this.saveToStorage();
        }
    }

    toggleDesktopNotifications(enabled) {
        if (enabled) {
            this.requestPermission();
        }
    }

    goToTask(taskId) {
        // Scroll to task in the list
        const taskElement = document.querySelector(`[data-task-id="${taskId}"]`);
        if (taskElement) {
            taskElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            taskElement.classList.add('highlight-task');
            setTimeout(() => taskElement.classList.remove('highlight-task'), 2000);
        }
        
        // Close notifications panel
        this.togglePanel();
    }

    playNotificationSound() {
        // Create audio context for notification sound
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = 800;
            oscillator.type = 'sine';
            
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.5);
        } catch (e) {
            console.log('Audio not supported:', e);
        }
    }

    saveToStorage() {
        localStorage.setItem('notifications', JSON.stringify(this.notifications));
    }

    loadFromStorage() {
        const saved = localStorage.getItem('notifications');
        if (saved) {
            this.notifications = JSON.parse(saved);
            this.updateNotificationUI();
        }
    }

    setupPeriodicChecks() {
        // Check for due tasks every 5 minutes
        setInterval(() => {
            this.checkDueTasks();
        }, 5 * 60 * 1000);
        
        // Check for inactivity every minute
        setInterval(() => {
            this.checkInactivity();
        }, 60 * 1000);
    }

    checkDueTasks() {
        // This would check tasks from the server
        // For now, it's a placeholder
        console.log('Checking due tasks...');
    }

    checkInactivity() {
        // Notify if user has been inactive for 30 minutes
        const lastActivity = localStorage.getItem('lastActivity');
        if (lastActivity) {
            const inactiveMinutes = (Date.now() - parseInt(lastActivity)) / (1000 * 60);
            if (inactiveMinutes > 30) {
                this.showNotification('Inactive for 30 minutes', 'Consider taking a break or saving your work.', 'system');
            }
        }
    }
}

// Track user activity
document.addEventListener('mousemove', () => {
    localStorage.setItem('lastActivity', Date.now());
});

document.addEventListener('keypress', () => {
    localStorage.setItem('lastActivity', Date.now());
});

// Initialize notification system
document.addEventListener('DOMContentLoaded', function() {
    if (window.socket) {
        window.notificationSystem = new NotificationSystem(window.socket);
    }
});