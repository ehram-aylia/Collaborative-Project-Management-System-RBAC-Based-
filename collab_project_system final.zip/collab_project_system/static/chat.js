// Real-time Chat System for Collaboration Board
class ChatSystem {
    constructor(socket) {
        this.socket = socket;
        this.currentTaskId = null;
        this.currentRoom = 'general';
        this.init();
    }

    init() {
        // Listen for chat messages
        this.socket.on('chat_message', (data) => {
            this.displayMessage(data);
        });

        this.socket.on('chat_history', (messages) => {
            this.displayHistory(messages);
        });

        this.socket.on('user_joined', (data) => {
            this.showSystemMessage(`${data.user} joined the chat`);
        });

        this.socket.on('user_left', (data) => {
            this.showSystemMessage(`${data.user} left the chat`);
        });

        // Initialize UI
        this.initUI();
    }

    initUI() {
        // Create chat container if it doesn't exist
        if (!document.getElementById('chat-container')) {
            const chatHTML = `
                <div id="chat-container" class="chat-container">
                    <div class="chat-header">
                        <h3><i class="fas fa-comments"></i> Team Chat</h3>
                        <div class="chat-controls">
                            <select id="chat-room">
                                <option value="general">General</option>
                                <option value="urgent">Urgent Issues</option>
                                <option value="tech">Technical</option>
                                <option value="task">Task-Specific</option>
                            </select>
                            <button id="close-chat"><i class="fas fa-times"></i></button>
                        </div>
                    </div>
                    <div class="chat-messages" id="chat-messages"></div>
                    <div class="chat-input">
                        <input type="text" id="chat-input" placeholder="Type your message...">
                        <button id="send-chat"><i class="fas fa-paper-plane"></i></button>
                        <button id="attach-file"><i class="fas fa-paperclip"></i></button>
                    </div>
                    <div class="chat-users" id="chat-users">
                        <h4>Online Users</h4>
                        <div id="users-list"></div>
                    </div>
                </div>
                <button id="chat-toggle" class="chat-toggle">
                    <i class="fas fa-comment-dots"></i>
                    <span class="chat-badge">0</span>
                </button>
            `;
            
            document.body.insertAdjacentHTML('beforeend', chatHTML);
            
            // Add event listeners
            document.getElementById('chat-toggle').addEventListener('click', () => this.toggleChat());
            document.getElementById('close-chat').addEventListener('click', () => this.toggleChat());
            document.getElementById('send-chat').addEventListener('click', () => this.sendMessage());
            document.getElementById('chat-input').addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.sendMessage();
            });
            document.getElementById('chat-room').addEventListener('change', (e) => {
                this.changeRoom(e.target.value);
            });
            document.getElementById('attach-file').addEventListener('click', () => this.attachFile());
        }
    }

    toggleChat() {
        const container = document.getElementById('chat-container');
        const toggleBtn = document.getElementById('chat-toggle');
        
        if (container.classList.contains('open')) {
            container.classList.remove('open');
            toggleBtn.classList.remove('active');
        } else {
            container.classList.add('open');
            toggleBtn.classList.add('active');
            
            // Join chat room
            this.socket.emit('join_chat', {
                room: this.currentRoom,
                user: window.user,
                role: window.role
            });
            
            // Load chat history
            this.socket.emit('get_chat_history', { room: this.currentRoom });
            
            // Focus on input
            setTimeout(() => {
                document.getElementById('chat-input').focus();
            }, 100);
        }
    }

    changeRoom(room) {
        this.currentRoom = room;
        
        // Leave current room
        this.socket.emit('leave_chat', { room: this.currentRoom });
        
        // Join new room
        this.socket.emit('join_chat', {
            room: room,
            user: window.user,
            role: window.role
        });
        
        // Clear messages
        document.getElementById('chat-messages').innerHTML = '';
        
        // Load new room history
        this.socket.emit('get_chat_history', { room: room });
        
        // Update title
        document.querySelector('.chat-header h3').innerHTML = 
            `<i class="fas fa-comments"></i> ${room.charAt(0).toUpperCase() + room.slice(1)} Chat`;
    }

    sendMessage() {
        const input = document.getElementById('chat-input');
        const message = input.value.trim();
        
        if (message) {
            const msgData = {
                room: this.currentRoom,
                user: window.user,
                role: window.role,
                message: message,
                timestamp: new Date().toISOString(),
                task_id: this.currentTaskId
            };
            
            this.socket.emit('send_chat', msgData);
            input.value = '';
            
            // Clear badge
            document.querySelector('.chat-badge').textContent = '0';
        }
    }

    displayMessage(data) {
        const messagesContainer = document.getElementById('chat-messages');
        const isOwnMessage = data.user === window.user;
        
        const messageHTML = `
            <div class="message ${isOwnMessage ? 'own-message' : ''}">
                <div class="message-header">
                    <span class="message-user ${data.role.toLowerCase()}">${data.user}</span>
                    <span class="message-role">${data.role}</span>
                    <span class="message-time">${new Date(data.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                </div>
                <div class="message-content">${this.escapeHtml(data.message)}</div>
                ${data.task_id ? `<div class="message-task">Task #${data.task_id}</div>` : ''}
            </div>
        `;
        
        messagesContainer.insertAdjacentHTML('beforeend', messageHTML);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Update badge if chat is closed
        if (!document.getElementById('chat-container').classList.contains('open')) {
            const badge = document.querySelector('.chat-badge');
            const current = parseInt(badge.textContent) || 0;
            badge.textContent = current + 1;
        }
    }

    displayHistory(messages) {
        const messagesContainer = document.getElementById('chat-messages');
        messagesContainer.innerHTML = '';
        
        messages.forEach(msg => this.displayMessage(msg));
    }

    showSystemMessage(text) {
        const messagesContainer = document.getElementById('chat-messages');
        
        const systemHTML = `
            <div class="system-message">
                <i class="fas fa-info-circle"></i> ${text}
            </div>
        `;
        
        messagesContainer.insertAdjacentHTML('beforeend', systemHTML);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    attachFile() {
        // Create file input
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = '.pdf,.doc,.docx,.jpg,.jpeg,.png,.txt';
        
        fileInput.onchange = (e) => {
            const file = e.target.files[0];
            if (file) {
                // In a real app, you would upload the file to server
                // For now, just send a message about the file
                const message = `📎 File attached: ${file.name} (${Math.round(file.size/1024)}KB)`;
                document.getElementById('chat-input').value = message;
                this.sendMessage();
            }
        };
        
        fileInput.click();
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    updateUsersList(users) {
        const usersList = document.getElementById('users-list');
        usersList.innerHTML = '';
        
        users.forEach(user => {
            const userHTML = `
                <div class="user-item">
                    <span class="user-status ${user.status}"></span>
                    <span class="user-name">${user.name}</span>
                    <span class="user-role ${user.role}">${user.role}</span>
                </div>
            `;
            usersList.insertAdjacentHTML('beforeend', userHTML);
        });
    }
}

// Initialize chat system when socket is available
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        if (window.socket && window.user) {
            window.chatSystem = new ChatSystem(window.socket);
        }
    }, 1000);
});