// Global variables
var socket = io();
var user = "";
var role = "";
var permissions = [];

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Get user info from template
    user = document.getElementById('user-data')?.dataset.user || "Guest";
    role = document.getElementById('user-data')?.dataset.role || "Guest";
    permissions = document.getElementById('user-data')?.dataset.permissions?.split(',') || [];
    
    // Initial load
    socket.emit("get_tasks");
    socket.emit("get_activity");
    updateStats(); // FIXED: Load stats on page load
    
    // Setup event listeners
    setupEventListeners();
    
    // Setup keyboard shortcuts
    setupKeyboardShortcuts();
});

// FIXED: Function to update dashboard stats - Now matches HTML IDs exactly
function updateStats() {
    fetch('/api/stats')
        .then(response => response.json())
        .then(data => {
            console.log('Stats received:', data); // Debug log
            
            // Update using exact IDs from HTML
            const totalEl = document.getElementById('total-tasks');
            const progressEl = document.getElementById('in-progress');
            const completedEl = document.getElementById('completed');
            const highPriorityEl = document.getElementById('high-priority');
            
            if (totalEl) totalEl.textContent = data.total;
            if (progressEl) progressEl.textContent = data.in_progress;
            if (completedEl) completedEl.textContent = data.completed;
            if (highPriorityEl) highPriorityEl.textContent = data.high_priority;
            
            console.log('Stats updated successfully!'); // Confirmation log
        })
        .catch(error => {
            console.error('Error fetching stats:', error);
        });
}

// Socket event handlers
socket.on("tasks", function(tasks) {
    let html = "";
    
    // Sort tasks by priority
    tasks.sort((a, b) => {
        const priorityOrder = { 'High': 1, 'Medium': 2, 'Low': 3 };
        return (priorityOrder[a.priority] || 4) - (priorityOrder[b.priority] || 4);
    });
    
    tasks.forEach(t => {
        // Determine card classes
        let cardClasses = "card";
        if (t.locked_by) cardClasses += " locked";
        if (t.priority === 'High') cardClasses += " high-priority";
        if (t.priority === 'Low') cardClasses += " low-priority";
        
        // Role badge
        const roleBadge = `<span class="role-badge badge-${t.role_required?.toLowerCase().replace(' ', '-') || 'any'}">
            ${t.role_required || 'Any'}
        </span>`;
        
        // Due date indicator
        let dueDateHtml = "";
        if (t.due_date) {
            const dueDate = new Date(t.due_date);
            const today = new Date();
            const daysDiff = Math.ceil((dueDate - today) / (1000 * 60 * 60 * 24));
            
            let dueClass = "due-normal";
            if (daysDiff < 0) dueClass = "due-overdue";
            else if (daysDiff <= 2) dueClass = "due-urgent";
            
            dueDateHtml = `<p class="due-date ${dueClass}">Due: ${t.due_date} (${daysDiff} days)</p>`;
        }
        
        html += `
        <div class="${cardClasses}" data-task-id="${t.id}">
            <div class="card-header">
                <h3>${t.title}</h3>
                ${roleBadge}
            </div>
            
            ${t.description ? `<p class="task-description">${t.description}</p>` : ''}
            
            <div class="task-details">
                <p><strong>Status:</strong> <span class="status-${t.status.toLowerCase().replace(' ', '-')}">${t.status}</span></p>
                <p><strong>Assigned to:</strong> ${t.assigned || 'Unassigned'}</p>
                <p><strong>Priority:</strong> <span class="priority-${t.priority.toLowerCase()}">${t.priority}</span></p>
                <p><strong>Created by:</strong> ${t.created_by || 'Unknown'}</p>
                ${dueDateHtml}
            </div>
            
            <div class="lock-info">
                ${t.locked_by ? 
                    `<div class="locked-by">
                        <span class="lock-icon">🔒</span> Locked by ${t.locked_by}
                    </div>` : 
                    '<div class="available">✅ Available</div>'
                }
            </div>
            
            <div class="task-actions">
        `;
        
        // FIXED: Show Lock/Unlock button based on current state
        if (hasPermission('lock') || hasPermission('unlock')) {
            if (t.locked_by === user) {
                // User has locked this task - show Unlock button
                html += `<button onclick="unlock(${t.id})" class="unlock-btn">🔓 Unlock</button>`;
            } else if (!t.locked_by) {
                // Task is not locked - show Lock button
                html += `<button onclick="lock(${t.id})">🔒 Lock</button>`;
            } else if (role === 'Manager') {
                // Manager can unlock any task
                html += `<button onclick="unlock(${t.id})" class="unlock-btn">🔓 Force Unlock</button>`;
            } else {
                // Task is locked by someone else
                html += `<button disabled class="disabled">🔒 Locked</button>`;
            }
        }
        
        // Show status dropdown
        if (hasPermission('update') && !(role === 'Reviewer' || role === 'UX Designer')) {
            html += `
                <select onchange="updateStatus(${t.id}, this.value)" ${t.locked_by && t.locked_by !== user ? 'disabled' : ''}>
                    <option value="To Do" ${t.status === 'To Do' ? 'selected' : ''}>To Do</option>
                    <option value="In Progress" ${t.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
                    <option value="In Review" ${t.status === 'In Review' ? 'selected' : ''}>In Review</option>
                    <option value="Done" ${t.status === 'Done' ? 'selected' : ''}>Done</option>
                </select>
            `;
        }
        
        if (hasPermission('delete') && (role === 'Manager' || role === 'Product Owner')) {
            html += `<button onclick="deleteTask(${t.id})" class="delete-btn">Delete</button>`;
        }
        
        if (hasPermission('update') && (role === 'Manager' || role === 'Product Owner' || t.assigned === user)) {
            html += `<button onclick="editTask(${t.id})" class="edit-btn">Edit</button>`;
        }
        
        html += `
            </div>
        </div>
        `;
    });
    
    document.getElementById("tasks").innerHTML = html;
    
    // Update task count
    document.getElementById("task-count").textContent = tasks.length;
});

socket.on("update", function(data) {
    // Refresh tasks
    socket.emit("get_tasks");
    
    // FIXED: Update stats when tasks change
    updateStats();
    
    // Show notification
    showNotification(`Task ${data.action.replace('_', ' ')}`, "info");
});

socket.on("activity", function(activities) {
    let html = "";
    activities.forEach(activity => {
        html += `
        <div class="activity-item">
            <span class="activity-user">${activity.user}</span>
            <span class="activity-action">${activity.action}</span>
            ${activity.details ? `<span class="activity-details">${activity.details}</span>` : ''}
            <span class="activity-time">${new Date(activity.timestamp).toLocaleTimeString()}</span>
        </div>
        `;
    });
    
    const activityContainer = document.getElementById("activity-feed");
    if (activityContainer) {
        activityContainer.innerHTML = html;
    }
});

socket.on("error", function(data) {
    showNotification(data.message, "error");
});

// Task management functions
function lock(taskId) {
    if (!user) return;
    socket.emit("lock_task", { task_id: taskId });
}

function unlock(taskId) {
    if (!user) return;
    socket.emit("unlock_task", { task_id: taskId });
}

function updateStatus(taskId, status) {
    if (!user) return;
    socket.emit("update_status", { task_id: taskId, status: status });
}

function addTask() {
    if (!hasPermission('create')) {
        showNotification("You don't have permission to add tasks", "error");
        return;
    }
    
    const title = document.getElementById("title").value.trim();
    const assigned = document.getElementById("assigned").value.trim();
    const priority = document.getElementById("priority").value;
    const roleRequired = document.getElementById("role-required").value;
    const description = document.getElementById("description").value.trim();
    
    if (!title) {
        showNotification("Please enter a task title", "error");
        return;
    }
    
    socket.emit("add_task", {
        title: title,
        assigned: assigned,
        priority: priority,
        role_required: roleRequired,
        description: description
    });
    
    // Clear form
    document.getElementById("title").value = "";
    document.getElementById("assigned").value = "";
    document.getElementById("description").value = "";
    
    showNotification("Task added successfully", "success");
}

function editTask(taskId) {
    // In a real application, this would open a modal or form
    // For now, we'll use a prompt-based approach
    const newTitle = prompt("Enter new task title:");
    if (newTitle) {
        socket.emit("update_task", {
            task_id: taskId,
            title: newTitle,
            status: document.querySelector(`[data-task-id="${taskId}"] select`)?.value || "To Do",
            assigned: "User", // This should come from the card
            priority: "Medium", // This should come from the card
            role_required: "Any" // This should come from the card
        });
    }
}

function deleteTask(taskId) {
    if (!hasPermission('delete')) {
        showNotification("You don't have permission to delete tasks", "error");
        return;
    }
    
    if (confirm("Are you sure you want to delete this task?")) {
        socket.emit("delete_task", { task_id: taskId });
    }
}

function refreshTasks() {
    socket.emit("get_tasks");
    socket.emit("get_activity");
    updateStats(); // FIXED: Update stats on refresh
    showNotification("Refreshed", "info");
}

// Permission checking
function hasPermission(action) {
    return permissions.includes(action);
}

// UI Helper functions
function showNotification(message, type = "info") {
    const notification = document.createElement("div");
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">×</button>
    `;
    
    document.getElementById("notifications").appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

function setupEventListeners() {
    // Add task form submit
    const addTaskForm = document.getElementById("add-task-form");
    if (addTaskForm) {
        addTaskForm.addEventListener("submit", function(e) {
            e.preventDefault();
            addTask();
        });
    }
    
    // Refresh button
    const refreshBtn = document.getElementById("refresh-btn");
    if (refreshBtn) {
        refreshBtn.addEventListener("click", refreshTasks);
    }
    
    // Filter tasks
    const filterSelect = document.getElementById("filter-tasks");
    if (filterSelect) {
        filterSelect.addEventListener("change", function() {
            filterTasks(this.value);
        });
    }
}

function setupKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl + N: Focus on new task title
        if (e.ctrlKey && e.key === 'n') {
            const titleInput = document.getElementById('title');
            if (titleInput) {
                e.preventDefault();
                titleInput.focus();
            }
        }
        
        // F5 or Ctrl + R: Refresh
        if (e.key === 'F5' || (e.ctrlKey && e.key === 'r')) {
            e.preventDefault();
            refreshTasks();
        }
        
        // Escape: Close all modals/notifications
        if (e.key === 'Escape') {
            const notifications = document.querySelectorAll('.notification');
            notifications.forEach(n => n.remove());
        }
    });
}

function filterTasks(filter) {
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        switch(filter) {
            case 'all':
                card.style.display = 'block';
                break;
            case 'assigned':
                const assignedTo = card.querySelector('p:nth-child(3)').textContent;
                if (assignedTo.includes(user)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
                break;
            case 'high':
                const priority = card.querySelector('.priority-high');
                if (priority) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
                break;
            case 'locked':
                if (card.classList.contains('locked')) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
                break;
        }
    });
}

// Accessibility features
function toggleHighContrast() {
    document.body.classList.toggle('high-contrast');
    localStorage.setItem('highContrast', document.body.classList.contains('high-contrast'));
}

function toggleLargeText() {
    document.body.classList.toggle('large-text');
    localStorage.setItem('largeText', document.body.classList.contains('large-text'));
}

// Load saved accessibility settings
window.addEventListener('load', function() {
    if (localStorage.getItem('highContrast') === 'true') {
        document.body.classList.add('high-contrast');
    }
    if (localStorage.getItem('largeText') === 'true') {
        document.body.classList.add('large-text');
    }
});

// Auto-refresh every 30 seconds
setInterval(function() {
    refreshTasks();
}, 30000);