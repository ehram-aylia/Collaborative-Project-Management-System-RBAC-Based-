-- ================================
-- 1️⃣ CREATE TABLES 
-- ================================

-- USERS TABLE
CREATE TABLE IF NOT EXISTS Users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL,
    permissions TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    last_login TEXT
);

-- TASKS TABLE
CREATE TABLE IF NOT EXISTS Tasks (
    task_id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'To Do',
    assigned_to TEXT,
    priority TEXT DEFAULT 'Medium',
    locked_by TEXT,
    locked_at TEXT,
    role_required TEXT DEFAULT 'Any',
    created_by TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT,
    due_date TEXT,
    description TEXT,
    dependencies TEXT,
    attachments TEXT
);

-- COMMENTS TABLE
CREATE TABLE IF NOT EXISTS Comments (
    comment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER,
    user TEXT,
    role TEXT,
    comment TEXT NOT NULL,
    timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES Tasks(task_id) ON DELETE CASCADE
);

-- ACTIVITY LOG TABLE
CREATE TABLE IF NOT EXISTS ActivityLog (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user TEXT,
    action TEXT,
    task_id INTEGER,
    details TEXT,
    timestamp TEXT DEFAULT CURRENT_TIMESTAMP
);

-- CHAT MESSAGES TABLE
CREATE TABLE IF NOT EXISTS ChatMessages (
    message_id INTEGER PRIMARY KEY AUTOINCREMENT,
    room TEXT NOT NULL,
    user TEXT NOT NULL,
    role TEXT NOT NULL,
    message TEXT NOT NULL,
    task_id INTEGER,
    timestamp TEXT DEFAULT CURRENT_TIMESTAMP
);

-- ================================
-- 2️⃣ CREATE INDEXES
-- ================================
CREATE INDEX IF NOT EXISTS idx_tasks_status ON Tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_priority ON Tasks(priority);
CREATE INDEX IF NOT EXISTS idx_tasks_assigned ON Tasks(assigned_to);
CREATE INDEX IF NOT EXISTS idx_activity_timestamp ON ActivityLog(timestamp);
CREATE INDEX IF NOT EXISTS idx_comments_task ON Comments(task_id);

-- ================================
-- 3️⃣ CLEAR EXISTING DATA
-- ================================
DELETE FROM Users;
DELETE FROM Tasks;
DELETE FROM Comments;
DELETE FROM ActivityLog;
DELETE FROM ChatMessages;

-- ================================
-- 4️⃣ INSERT SAMPLE USERS
-- ================================
INSERT INTO Users (username, role, permissions) VALUES
('admin', 'Manager', 'create,read,update,delete,assign,lock,unlock,prioritize,manage_users,force_unlock'),
('ehram', 'Developer', 'read,update,lock,unlock,comment,upload,change_status'),
('sara', 'Reviewer', 'read,comment,approve,reject,review'),
('kamran', 'Product Owner', 'create,read,update,prioritize,review,backlog,force_unlock'),
('bilal', 'QA Tester', 'read,update,test,report,comment,bug_report'),
('ayesha', 'UX Designer', 'read,upload,comment,design,prototype'),
('farhan', 'DevOps Engineer', 'read,deploy,monitor,configure,backup');

-- ================================
-- 5️⃣ INSERT SAMPLE TASKS (7 Tasks)
-- ================================
INSERT INTO Tasks (title, status, assigned_to, priority, role_required, created_by, due_date, description) 
VALUES
('Design Homepage UI', 'In Progress', 'ayesha', 'High', 'UX Designer', 'admin', date('now', '+7 days'), 'Design responsive homepage with modern UI components and user-friendly interface.'),
('Implement User Authentication', 'To Do', 'ehram', 'High', 'Developer', 'admin', date('now', '+5 days'), 'Create secure login/registration system with JWT tokens and password encryption.'),
('Database Schema Design', 'Done', 'farhan', 'Medium', 'DevOps Engineer', 'admin', date('now', '-2 days'), 'Design and implement database schema with proper relationships and indexes.'),
('API Documentation', 'To Do', 'sara', 'Low', 'Reviewer', 'admin', date('now', '+10 days'), 'Write comprehensive API documentation with examples and error codes.'),
('Integration Testing', 'In Progress', 'bilal', 'High', 'QA Tester', 'admin', date('now', '+6 days'), 'Test all API endpoints and integration points between modules.'),
('Performance Optimization', 'To Do', 'ehram', 'Medium', 'Developer', 'admin', date('now', '+8 days'), 'Optimize application performance, reduce loading times, and fix memory leaks.'),
('Security Audit', 'To Do', 'bilal', 'High', 'QA Tester', 'admin', date('now', '+4 days'), 'Conduct security audit, check vulnerabilities, and implement security best practices.');

-- ================================
-- 6️⃣ INSERT SAMPLE ACTIVITY
-- ================================
INSERT INTO ActivityLog (user, action, task_id, details) VALUES
('admin', 'login', NULL, 'Logged into the system'),
('admin', 'add_task', 1, 'Added task: Design Homepage UI'),
('admin', 'add_task', 2, 'Added task: Implement User Authentication'),
('ehram', 'login', NULL, 'Logged into the system'),
('ehram', 'lock_task', 1, 'Locked task for editing'),
('ayesha', 'login', NULL, 'Logged into the system'),
('ayesha', 'update_status', 1, 'Changed status to: In Progress');

-- ================================
-- 7️⃣ VERIFICATION
-- ================================
SELECT '=== SYSTEM READY ===' as Info;
SELECT 'Database: collabdb.db (SQLite)' as Info;
SELECT 'Tables created successfully!' as Info;
SELECT ' ' as Space;
SELECT '=== USER COUNT ===' as Info;
SELECT COUNT(*) as Users_Count FROM Users;
SELECT '=== TASK COUNT ===' as Info;
SELECT COUNT(*) as Tasks_Count FROM Tasks;
SELECT '=== ACTIVITY COUNT ===' as Info;
SELECT COUNT(*) as Activity_Count FROM ActivityLog;

-- ================================
-- 8️⃣ FINAL MESSAGE
-- ================================
SELECT ' ' as Space;
SELECT '========================================' as Info;
SELECT 'COLLABORATION BOARD SYSTEM SETUP COMPLETE' as Info;
SELECT '========================================' as Info;
SELECT 'Database: collabdb.db (SQLite)' as Info;
SELECT 'Tables: Users, Tasks, Comments, ActivityLog, ChatMessages' as Info;
SELECT 'Sample Data: 7 users, 7 tasks inserted' as Info;
SELECT '========================================' as Info;
SELECT 'Start the application with: python app.py' as Info;
SELECT 'Access at: http://localhost:5000' as Info;
SELECT 'Default login: admin (Manager)' as Info;
SELECT '========================================' as Info;