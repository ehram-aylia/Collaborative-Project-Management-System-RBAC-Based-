from flask import Flask, render_template, request, redirect, session, jsonify
from flask_socketio import SocketIO, emit
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json
import os

app = Flask(__name__)
app.secret_key = "secret123_collab_project_2024"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///collabdb.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

socketio = SocketIO(app, cors_allowed_origins="*")
db = SQLAlchemy(app)

# ==================== DATABASE MODELS ====================
class User(db.Model):
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    role = db.Column(db.String(20), nullable=False)
    permissions = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.now)

class Task(db.Model):
    task_id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), default='To Do')
    assigned_to = db.Column(db.String(50))
    priority = db.Column(db.String(10), default='Medium')
    locked_by = db.Column(db.String(50))
    role_required = db.Column(db.String(20), default='Any')
    created_by = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, onupdate=datetime.now)
    due_date = db.Column(db.Date)
    description = db.Column(db.Text)
    dependencies = db.Column(db.String(500))
    attachments = db.Column(db.String(500))

class Comment(db.Model):
    comment_id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('task.task_id'))
    user = db.Column(db.String(50))
    comment = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.now)

class ActivityLog(db.Model):
    log_id = db.Column(db.Integer, primary_key=True)
    user = db.Column(db.String(50))
    action = db.Column(db.String(50))
    task_id = db.Column(db.Integer)
    details = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.now)

# Create tables
with app.app_context():
    db.create_all()

# ==================== HELPER FUNCTIONS ====================
# Role permissions mapping
ROLE_PERMISSIONS = {
    "Manager": ["create", "read", "update", "delete", "assign", "lock", "unlock", "prioritize", "manage_users"],
    "Developer": ["read", "update", "lock", "unlock", "comment", "upload", "change_status"],
    "Reviewer": ["read", "comment", "approve", "reject", "review"],
    "Product Owner": ["create", "read", "update", "prioritize", "review", "backlog"],
    "QA Tester": ["read", "update", "test", "report", "comment", "bug_report"],
    "UX Designer": ["read", "upload", "comment", "design", "prototype"],
    "DevOps Engineer": ["read", "deploy", "monitor", "configure", "backup"]
}

def check_permission(role, action):
    """Check if a role has permission for an action"""
    return action in ROLE_PERMISSIONS.get(role, [])

def log_activity(user, action, task_id=None, details=None):
    """Log user activity to database"""
    try:
        activity = ActivityLog(
            user=user,
            action=action,
            task_id=task_id,
            details=details,
            timestamp=datetime.now()
        )
        db.session.add(activity)
        db.session.commit()
    except Exception as e:
        print(f"Activity log error: {e}")

# ==================== ROUTES ====================
@app.route("/", methods=["GET"])
def index():
    if "user" not in session:
        return redirect("/login")
    
    # Get user's permissions
    permissions = ROLE_PERMISSIONS.get(session["role"], [])
    
    return render_template("index.html",
        user=session["user"],
        role=session["role"],
        permissions=permissions
    )

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        role = request.form["role"]
        
        # Save to session
        session["user"] = username
        session["role"] = role
        
        try:
            # Check if user exists
            user = User.query.filter_by(username=username).first()
            if user is None:
                # Insert new user
                permissions = ','.join(ROLE_PERMISSIONS.get(role, []))
                new_user = User(
                    username=username,
                    role=role,
                    permissions=permissions,
                    created_at=datetime.now()
                )
                db.session.add(new_user)
                db.session.commit()
            
            # Log login activity
            log_activity(username, "login")
            
            return redirect("/")
        except Exception as e:
            print(f"Login error: {e}")
            return f"Login error: {e}"
    
    return render_template("login.html")

@app.route("/logout")
def logout():
    if "user" in session:
        log_activity(session["user"], "logout")
    session.clear()
    return redirect("/login")

@app.route("/api/tasks")
def get_tasks_api():
    """API endpoint for getting tasks"""
    if "user" not in session:
        return jsonify({"error": "Not authenticated"}), 401
    
    try:
        # Check user role for filtering
        if session["role"] in ["Manager", "Product Owner"]:
            tasks = Task.query.order_by(
                db.case(
                    {"High": 1, "Medium": 2, "Low": 3},
                    value=Task.priority,
                    else_=4
                ),
                Task.created_at.desc()
            ).all()
        else:
            tasks = Task.query.filter(
                (Task.assigned_to == session["user"]) | 
                (Task.role_required == session["role"]) | 
                (Task.role_required == 'Any')
            ).order_by(
                db.case(
                    {"High": 1, "Medium": 2, "Low": 3},
                    value=Task.priority,
                    else_=4
                ),
                Task.created_at.desc()
            ).all()
        
        tasks_list = []
        for task in tasks:
            tasks_list.append({
                "id": task.task_id,
                "title": task.title,
                "status": task.status,
                "assigned": task.assigned_to,
                "priority": task.priority,
                "locked_by": task.locked_by,
                "role_required": task.role_required,
                "created_by": task.created_by,
                "due_date": str(task.due_date) if task.due_date else None,
                "description": task.description
            })
        
        return jsonify(tasks_list)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# NEW: API endpoint for dashboard stats
@app.route("/api/stats")
def get_stats_api():
    """API endpoint for getting dashboard statistics"""
    if "user" not in session:
        return jsonify({"error": "Not authenticated"}), 401
    
    try:
        # Get tasks based on user role
        if session["role"] in ["Manager", "Product Owner"]:
            tasks = Task.query.all()
        else:
            tasks = Task.query.filter(
                (Task.assigned_to == session["user"]) | 
                (Task.role_required == session["role"]) | 
                (Task.role_required == 'Any')
            ).all()
        
        total = len(tasks)
        in_progress = len([t for t in tasks if t.status == 'In Progress'])
        completed = len([t for t in tasks if t.status == 'Done'])
        high_priority = len([t for t in tasks if t.priority == 'High'])
        
        return jsonify({
            "total": total,
            "in_progress": in_progress,
            "completed": completed,
            "high_priority": high_priority
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ==================== SOCKET.IO EVENTS ====================

@socketio.on("connect")
def handle_connect():
    print(f"Client connected: {request.sid}")

@socketio.on("disconnect")
def handle_disconnect():
    print(f"Client disconnected: {request.sid}")

@socketio.on("get_tasks")
def handle_get_tasks():
    """Send tasks to connected client"""
    if "user" not in session:
        return
    
    try:
        # Get tasks based on user role
        if session["role"] in ["Manager", "Product Owner"]:
            tasks = Task.query.order_by(
                db.case(
                    {"High": 1, "Medium": 2, "Low": 3},
                    value=Task.priority,
                    else_=4
                ),
                Task.created_at.desc()
            ).all()
        else:
            tasks = Task.query.filter(
                (Task.assigned_to == session["user"]) | 
                (Task.role_required == session["role"]) | 
                (Task.role_required == 'Any')
            ).order_by(
                db.case(
                    {"High": 1, "Medium": 2, "Low": 3},
                    value=Task.priority,
                    else_=4
                ),
                Task.created_at.desc()
            ).all()
        
        tasks_data = []
        for task in tasks:
            # Get assignee role
            assignee_role = None
            if task.assigned_to:
                user = User.query.filter_by(username=task.assigned_to).first()
                assignee_role = user.role if user else None
            
            tasks_data.append({
                "id": task.task_id,
                "title": task.title,
                "status": task.status,
                "assigned": task.assigned_to,
                "priority": task.priority,
                "locked_by": task.locked_by,
                "role_required": task.role_required,
                "assignee_role": assignee_role,
                "description": task.description,
                "due_date": str(task.due_date) if task.due_date else None
            })
        
        emit("tasks", tasks_data)
    except Exception as e:
        print(f"Get tasks error: {e}")
        emit("error", {"message": str(e)})

@socketio.on("add_task")
def handle_add_task(data):
    """Add new task"""
    if "user" not in session:
        emit("error", {"message": "Not authenticated"})
        return
    
    if not check_permission(session["role"], "create"):
        emit("error", {"message": "Permission denied"})
        return
    
    try:
        new_task = Task(
            title=data["title"],
            status='To Do',
            assigned_to=data.get("assigned", ""),
            priority=data.get("priority", "Medium"),
            role_required=data.get("role_required", "Any"),
            created_by=session["user"],
            created_at=datetime.now(),
            description=data.get("description", "")
        )
        
        db.session.add(new_task)
        db.session.commit()
        
        # Log activity
        log_activity(session["user"], "add_task", new_task.task_id, 
                    f"Added task: {data['title']}")
        
        # Broadcast update to all clients
        socketio.emit("update", {"action": "task_added", "task_id": new_task.task_id})
    except Exception as e:
        print(f"Add task error: {e}")
        emit("error", {"message": str(e)})

@socketio.on("update_task")
def handle_update_task(data):
    """Update existing task"""
    if "user" not in session:
        emit("error", {"message": "Not authenticated"})
        return
    
    if not check_permission(session["role"], "update"):
        emit("error", {"message": "Permission denied"})
        return
    
    try:
        task = Task.query.get(data["task_id"])
        
        if not task:
            emit("error", {"message": "Task not found"})
            return
        
        # Check if task is locked by someone else
        if task.locked_by and task.locked_by != session["user"]:
            emit("error", {"message": f"Task is locked by {task.locked_by}"})
            return
        
        # Update task
        task.title = data["title"]
        task.status = data["status"]
        task.assigned_to = data["assigned"]
        task.priority = data["priority"]
        task.role_required = data.get("role_required", "Any")
        task.description = data.get("description", "")
        task.updated_at = datetime.now()
        
        db.session.commit()
        
        # Log activity
        log_activity(session["user"], "update_task", data["task_id"], 
                    f"Updated task: {data['title']}")
        
        # Broadcast update
        socketio.emit("update", {"action": "task_updated", "task_id": data["task_id"]})
    except Exception as e:
        print(f"Update task error: {e}")
        emit("error", {"message": str(e)})

@socketio.on("delete_task")
def handle_delete_task(data):
    """Delete task"""
    if "user" not in session:
        emit("error", {"message": "Not authenticated"})
        return
    
    if not check_permission(session["role"], "delete"):
        emit("error", {"message": "Permission denied"})
        return
    
    try:
        task = Task.query.get(data["task_id"])
        
        if not task:
            emit("error", {"message": "Task not found"})
            return
        
        task_title = task.title
        
        # Delete task
        db.session.delete(task)
        db.session.commit()
        
        # Log activity
        log_activity(session["user"], "delete_task", data["task_id"], 
                    f"Deleted task: {task_title}")
        
        # Broadcast update
        socketio.emit("update", {"action": "task_deleted", "task_id": data["task_id"]})
    except Exception as e:
        print(f"Delete task error: {e}")
        emit("error", {"message": str(e)})

@socketio.on("lock_task")
def handle_lock_task(data):
    """Lock task for editing"""
    if "user" not in session:
        emit("error", {"message": "Not authenticated"})
        return
    
    if not check_permission(session["role"], "lock"):
        emit("error", {"message": "Permission denied"})
        return
    
    try:
        task = Task.query.get(data["task_id"])
        
        if not task:
            emit("error", {"message": "Task not found"})
            return
        
        # Check if already locked
        if task.locked_by and task.locked_by != session["user"]:
            emit("error", {"message": f"Task is already locked by {task.locked_by}"})
            return
        
        # Lock the task
        task.locked_by = session["user"]
        db.session.commit()
        
        log_activity(session["user"], "lock_task", data["task_id"])
        socketio.emit("update", {"action": "task_locked", "task_id": data["task_id"], "user": session["user"]})
        
    except Exception as e:
        print(f"Lock task error: {e}")
        emit("error", {"message": str(e)})

@socketio.on("unlock_task")
def handle_unlock_task(data):
    """Unlock task"""
    if "user" not in session:
        emit("error", {"message": "Not authenticated"})
        return
    
    try:
        task = Task.query.get(data["task_id"])
        
        if not task:
            emit("error", {"message": "Task not found"})
            return
        
        # FIXED: Allow Manager to unlock any task, or the user who locked it
        if task.locked_by != session["user"] and session["role"] != "Manager":
            emit("error", {"message": "You don't have permission to unlock this task"})
            return
        
        # Unlock task
        task.locked_by = None
        db.session.commit()
        
        log_activity(session["user"], "unlock_task", data["task_id"])
        socketio.emit("update", {"action": "task_unlocked", "task_id": data["task_id"]})
        
    except Exception as e:
        print(f"Unlock task error: {e}")
        emit("error", {"message": str(e)})

@socketio.on("update_status")
def handle_update_status(data):
    """Update task status"""
    if "user" not in session:
        emit("error", {"message": "Not authenticated"})
        return
    
    if not check_permission(session["role"], "update"):
        emit("error", {"message": "Permission denied"})
        return
    
    try:
        task = Task.query.get(data["task_id"])
        
        if not task:
            emit("error", {"message": "Task not found"})
            return
        
        task.status = data["status"]
        task.updated_at = datetime.now()
        db.session.commit()
        
        # Log activity
        log_activity(session["user"], "update_status", data["task_id"], 
                    f"Changed status to: {data['status']}")
        
        # Broadcast update
        socketio.emit("update", {"action": "status_updated", "task_id": data["task_id"]})
    except Exception as e:
        print(f"Update status error: {e}")
        emit("error", {"message": str(e)})

@socketio.on("get_activity")
def handle_get_activity():
    """Get recent activity"""
    if "user" not in session:
        return
    
    try:
        activities = ActivityLog.query.order_by(ActivityLog.timestamp.desc()).limit(20).all()
        
        activities_list = []
        for activity in activities:
            activities_list.append({
                "user": activity.user,
                "action": activity.action,
                "task_id": activity.task_id,
                "details": activity.details,
                "timestamp": str(activity.timestamp)
            })
        
        emit("activity", activities_list)
    except Exception as e:
        print(f"Get activity error: {e}")

# Add sample data on startup
def add_sample_data():
    with app.app_context():
        if User.query.count() == 0:
            sample_users = [
                User(username="admin", role="Manager", permissions="create,read,update,delete,assign,lock,unlock"),
                User(username="developer1", role="Developer", permissions="read,update,lock,unlock,comment"),
                User(username="designer1", role="UX Designer", permissions="read,upload,comment,design")
            ]
            db.session.add_all(sample_users)
            db.session.commit()
        
        if Task.query.count() == 0:
            sample_tasks = [
                Task(
                    title="Design Homepage", 
                    status="To Do", 
                    assigned_to="designer1", 
                    priority="High",
                    created_by="admin",
                    description="Complete homepage design with responsive layout"
                ),
                Task(
                    title="API Development", 
                    status="In Progress", 
                    assigned_to="developer1", 
                    priority="High",
                    created_by="admin",
                    description="Implement REST API endpoints"
                ),
                Task(
                    title="Database Setup", 
                    status="To Do", 
                    assigned_to="admin", 
                    priority="Medium",
                    created_by="admin",
                    description="Configure production database"
                ),
                Task(
                    title="Testing", 
                    status="To Do", 
                    assigned_to="developer1", 
                    priority="Low",
                    created_by="admin",
                    description="Perform unit and integration testing"
                )
            ]
            db.session.add_all(sample_tasks)
            db.session.commit()

if __name__ == "__main__":
    # Add sample data
    add_sample_data()
    
    print("🚀 Starting Collaboration System...")
    print("📦 Using SQLite database: collabdb.db")
    print("🌐 Server running at: http://localhost:5000")
    print("📡 SocketIO ready for real-time updates")
    
    socketio.run(app, debug=True, host="0.0.0.0", port=5000, allow_unsafe_werkzeug=True)